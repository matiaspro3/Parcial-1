
<script type="text/javascript" src="js/funcionesUser.js"></script>
<?php  /*
		
			<h4 class="widgettitle">Botones ABM</h4>
			<ul>
				<li><a onclick="Mostrar('MostrarGrilla')" class=" btn-lg MiBotonUTN" ><span class="glyphicon glyphicon-th">&nbsp;</span>Grilla CD</a></li>
				<li><a onclick="Mostrar('MostrarFormAlta')" class="btn-lg MiBotonUTN" ><span class="glyphicon glyphicon-plus-sign">&nbsp;</span>Alta CD</a></li>
			
			</ul>
		</section>

<li><a onclick="MostrarGrilla()" class="btn">Mostrar Tabla </a> </li>
								<li><a onclick="MostarLogin()"  class="btn"id="BotonLogin" >Login</a> </li>



	echo "<li><a  onclick="Alta()"   value="miperfil"  class="btn">Perfil </a> </li> ";
 */?>
<li><a onclick="MostrarUser()" id="mostrandoperfil" class="btn" >Mi Perfil</a> </li>

